﻿namespace J2534DotNet
{
    public struct SConfig
    {
        public ConfigParameter Parameter;
        public int Value;
    }
}
